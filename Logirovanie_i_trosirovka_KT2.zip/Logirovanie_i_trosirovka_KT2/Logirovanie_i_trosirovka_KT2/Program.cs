﻿using Serilog;
using System;
using Serilog.Events;



namespace Logirovanie_i_trosirovka_KT2
{
    class Program
    {
        static void Main()
        {
            // Настраиваем логер
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug() // Установка мин уровень логирования
                .WriteTo.Console( // Вывод лога в консоль
                    outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}") // Настройка формата 
                .WriteTo.File(
                    path: "logs/log-.txt", // Путь к файлам с логами
                    rollingInterval: RollingInterval.Day, // Чередование по дням
                    restrictedToMinimumLevel: LogEventLevel.Information, // Мин уровень для файла
                    outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
                .CreateLogger();

            try
            {
                Log.Information("Приложение запущено");

                // Примеры логирования
                Log.Debug("Это отладочное сообщение (видно только в консоли)");

                PerformTask("Task 1", true);
                PerformTask("Task 2", false);

                Log.Information("Приложение завершает работу");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Произошла непредвиденная ошибка");
            }
            finally
            {
                Log.CloseAndFlush(); // Нужно для корректного завершения процесса
            }
            Console.ReadLine();
        }

        static void PerformTask(string taskName, bool success)
        {
            Log.Information("Начато выполнение задачи: {TaskName}", taskName);

            if (!success)
            {
                Log.Warning("Задача {TaskName} выполнена с проблемами", taskName);
            }
            else
            {
                Log.Information("Задача {TaskName} успешно выполнена", taskName);
            }
        }
    }
}